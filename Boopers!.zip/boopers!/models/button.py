import pygame
from constants import WINDOW_HEIGHT, WINDOW_WIDTH, GAME_COLOR

# make a button class


class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, content="", color=GAME_COLOR):
        """This will generate the button, but will not draw it"""
        self.color = color  # this will be the color that appears on screen
        self.x = x
        self.y = y
        self.height = height
        self.width = width
        self.content = content
        self.default_color = color  # this will be the colour when not hovered
        self.hovered_color = tuple(
            [i + 40 if i + 40 <= 255 else 255 for i in list(self.color)]
        )  # this will be the colour on hover

        self.hover_sound = pygame.mixer.Sound("./audio/hit.wav")  # load sound

    def draw(self, window, outline=None):
        """This will draw the button to the screen"""
        if outline:
            pygame.draw.rect(
                window,
                outline,
                (self.x - 2, self.y - 2, self.width * 1.1, self.height * 1.1),
                0,
            )

        # draw their box
        pygame.draw.rect(
            window, self.color, (self.x, self.y, self.width, self.height), 0
        )

        # set the font here
        if self.content:
            font = pygame.font.SysFont(
                "comic sans", int((self.width / 20) * (self.height / 30))
            )
            text = font.render(self.content, 1, (255, 255, 255))
            window.blit(
                text,
                (
                    self.x + (self.width / 2 - text.get_width() / 2),
                    self.y + (self.height / 2 - text.get_height() / 2),
                ),
            )

    def clicked(self, mouse):
        """
        This will return true when the button is clicked
        mouse = (x, y)
        """

        if mouse[0] > self.x and mouse[0] < self.x + self.width:
            if mouse[1] > self.y and mouse[1] < self.y + self.height:
                return True

    def hover(self, mouse):
        """
        This will return true when hovered and change the text color
        mouse = (x, y)
        """

        if mouse[0] > self.x and mouse[0] < self.x + self.width:
            if mouse[1] > self.y and mouse[1] < self.y + self.height:
                if self.color != self.hovered_color:
                    pygame.mixer.Sound.play(self.hover_sound)
                    self.color = self.hovered_color
                return True  # can be used to add extra features on hover
            else:
                self.color = self.default_color
        else:
            self.color = self.default_color
