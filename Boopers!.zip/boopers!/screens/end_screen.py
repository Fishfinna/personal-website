import pygame
from .base_screen import Screen
from models.button import Button
from constants import WINDOW_HEIGHT, WINDOW_WIDTH, GAME_COLOR, RED_COLOR, GREEN_COLOR


class EndScreen(Screen):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.quit_button = Button(
            WINDOW_WIDTH / 2 - WINDOW_WIDTH / 8,  # x
            WINDOW_HEIGHT / 4 + WINDOW_HEIGHT / 2,  # y
            WINDOW_WIDTH / 4,  # width
            WINDOW_HEIGHT / 10,  # height
            "quit",  # text
            color=RED_COLOR,
        )  # color

        self.game_over = False
        self.replay_button = Button(
            WINDOW_WIDTH / 2 - WINDOW_WIDTH / 8,  # x
            WINDOW_HEIGHT / 2 + self.quit_button.height,  # y
            WINDOW_WIDTH / 4,  # width
            WINDOW_HEIGHT / 10,  # height
            "replay",  # text
            color=GREEN_COLOR,
        )  # color

        # this will trigger on a replay
        self.replay_game = False

    def process_event(self, event):

        # this will exit the game
        if event.type == pygame.locals.QUIT:
            self.running = False

        # hover checks for button settings
        if event.type == pygame.MOUSEMOTION:

            self.quit_button.hover((event.pos[0], event.pos[1]))

            self.replay_button.hover((event.pos[0], event.pos[1]))

        # exit key check
        if event.type == pygame.K_ESCAPE:
            self.game_over = True
            self.running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x = event.pos[0]
            mouse_y = event.pos[1]

            if self.quit_button.clicked((mouse_x, mouse_y)):
                self.game_over = True
                self.running = False
            if self.replay_button.clicked((mouse_x, mouse_y)):
                self.p1_score = 0
                self.p2_score = 0
                self.replay_game = True
                self.running = False

    def process_loop(self):
        self.print_out(
            WINDOW_WIDTH / 2, WINDOW_HEIGHT / 10, "GAME OVER", color=GAME_COLOR, size=20
        )

        if self.p1_score or self.p2_score:
            self.print_out(
                WINDOW_WIDTH / 2,
                WINDOW_HEIGHT / 3.8,
                f"Player One: { self.p1_score }\
                               Player Two: { self.p2_score }",
                color=GAME_COLOR,
                size=35,
            )
            if self.p1_score > self.p2_score:
                self.print_out(
                    WINDOW_WIDTH / 2,
                    self.replay_button.y - WINDOW_HEIGHT * 0.2,
                    f"Player One Wins!!!",
                    color=GAME_COLOR,
                    size=30,
                )
            else:
                self.print_out(
                    WINDOW_WIDTH / 2,
                    self.replay_button.y - WINDOW_HEIGHT * 0.2,
                    f"Player Two Wins!!!",
                    color=GAME_COLOR,
                    size=30,
                )
        self.replay_button.draw(self.window)
        self.quit_button.draw(self.window)
