import pygame
from constants import LIMITS, WINDOW_HEIGHT, WINDOW_WIDTH, GAME_COLOR


class Paddle(pygame.sprite.Sprite):
    """Paddle class"""

    def __init__(
        self,
        position,
        color=GAME_COLOR,
        speed=10,
        width=WINDOW_WIDTH / 30,
        hight=WINDOW_HEIGHT / 8,
    ):
        super().__init__()

        # Default size
        self.size = (width, hight)

        # Default speed
        self.speed = speed

        self.color = color
        self.refresh_rect(color)

        # Starting positions
        if position == "left":
            self.rect.x = LIMITS["left"]
        elif position == "right":
            self.rect.x = LIMITS["right"] - self.size[0]

        self.rect.y = LIMITS["down"] // 2

    def refresh_rect(self, color):
        """Updates the sprite / rect based on self.size"""
        self.image = pygame.Surface(self.size)
        self.image.fill(color)
        self.rect = self.image.get_rect()

    def up(self):
        """Move the paddle up"""
        self.rect.y = self.rect.y - self.speed
        if self.rect.y < LIMITS["up"]:
            self.rect.y = LIMITS["up"]

    def down(self):
        """Move the paddle down"""
        self.rect.y = self.rect.y + self.speed
        if self.rect.y > LIMITS["down"] - self.size[1]:
            self.rect.y = LIMITS["down"] - self.size[1]

    def left(self, side="left"):
        """Move the paddle left, will keep them on their halves of the screen"""
        if side == "left":
            self.rect.x = self.rect.x - self.speed
            if self.rect.x < LIMITS["left"]:
                self.rect.x = LIMITS["left"]
        else:
            self.rect.x = self.rect.x - self.speed
            if self.rect.x < LIMITS["left"] + WINDOW_WIDTH / 2:
                self.rect.x = LIMITS["left"] + WINDOW_WIDTH / 2

    def right(self, side="left"):
        """Move the paddle right, will keep them on their halves of the screen"""
        if side == "left":
            self.rect.x = self.rect.x + self.speed
            if self.rect.x > LIMITS["right"] / 2 - self.size[0]:
                self.rect.x = LIMITS["right"] / 2 - self.size[0]

        else:
            self.rect.x = self.rect.x + self.speed
            if self.rect.x > LIMITS["right"] - self.size[0]:
                self.rect.x = LIMITS["right"] - self.size[0]
