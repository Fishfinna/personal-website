import random
import pygame
from constants import (
    LIMITS,
    GAME_COLOR,
    WINDOW_HEIGHT,
    WINDOW_HEIGHT,
    WINDOW_WIDTH,
    RED_COLOR,
    GREEN_COLOR,
)


class Ball(pygame.sprite.Sprite):
    """
    Model of a (bouncing) ball.
    If gravity is True, the ball will obey to gravity (aka fall down).
    """

    def __init__(
        self,
        gravity=False,
        color=None,
        size=(((WINDOW_HEIGHT + WINDOW_WIDTH) / 2 / 30)),
    ):
        """Constructor for the ball class"""
        super().__init__()

        self.size = int(size)
        # The ball is a circle
        self.image = pygame.Surface((size, size))
        self.image.set_colorkey((0, 0, 0))

        if color == None:
            color = GAME_COLOR
        pygame.draw.circle(self.image, color, (size // 2, size // 2), size // 2)
        self.rect = self.image.get_rect()
        self.color = color

        # Spawn in the middle of the screen
        self.rect.x = LIMITS["right"] // 2
        self.rect.y = LIMITS["down"] // 2

        # Start without moving
        self.hspeed = 0
        self.vspeed = 0

        # Gravity will be turned on for high value balls
        self.respect_gravity = gravity
        self.off_limits = False

        # bring in the wall hit noise
        pygame.mixer.init()  # start mixer
        self.wall_sound = pygame.mixer.Sound("./audio/wall.wav")  # load sound

    def launch(self, hspeed=int(WINDOW_WIDTH / 100), vspeed=int(WINDOW_HEIGHT / 110)):
        """Launches the ball up in the air"""
        try:
            self.hspeed = random.choice(
                [n for n in range(int(-hspeed), int(hspeed)) if n > 1 or n < -1]
            )  # this will make the bounces more
        except:
            self.hspeed = hspeed

        self.hspeed = -self.hspeed

        self.vspeed = vspeed * random.choice([-1, 1])
        self.vspeed = -self.vspeed

    def update(self):
        """Convenience method"""

        # The vertical speed decreases over time when subject to gravity
        if self.respect_gravity:
            self.vspeed += self.vspeed * 0.005

        # If the ball is not off limits, make it move
        if not self.off_limits:
            self.rect.x += self.hspeed
            self.rect.y += self.vspeed

        # Check the ball did not go off limits
        if self.rect.x > LIMITS["right"] - self.size:
            self.rect.x = LIMITS["right"] - self.size
            self.off_limits = True
        elif self.rect.x < LIMITS["left"]:
            self.rect.x = LIMITS["left"]
            self.off_limits = True

        # Check whether we need to bounce the ball
        if self.rect.y > LIMITS["down"] - self.size * 1.1:
            self.rect.y = LIMITS["down"] - self.size * 1.1
            pygame.mixer.Sound.play(self.wall_sound)
            self.bounce("vertical")
        elif self.rect.y < LIMITS["up"]:
            self.rect.y = LIMITS["up"]
            pygame.mixer.Sound.play(self.wall_sound)
            self.bounce("vertical")

        # Prevent the ball from bouncing as much
        if (
            self.respect_gravity
            and -1 < self.vspeed < 1
            and self.rect.y >= LIMITS["down"] - (self.size + 5)
        ):
            self.vspeed -= self.vspeed * 0.3

    def bounce(self, direction=None, power=False):
        """Bounce the ball"""

        # Horizontal bounces slightly decrease horizontal speed
        if direction in ("right", "left", "horizontal"):
            self.hspeed = -self.hspeed * 1.3
            self.vspeed -= random.choice([-self.vspeed * 2, self.vspeed * 2])

        # Vertical bounces decrease vertical speed
        if direction in ("up", "down", "vertical"):
            self.vspeed = -self.vspeed * 0.5

        # Power bounce: increase the speed of the ball
        if power == "left":
            self.hspeed *= -3
            self.vspeed *= -3
        if power == "right":
            self.hspeed *= 3
            self.vspeed *= 3
