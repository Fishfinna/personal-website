import pygame
from .base_screen import Screen
import constants
from models import Ball, Paddle
import pygame.locals
import constants
import random
import sys


class GameScreen(Screen):
    """Game Controller for the main game"""

    def __init__(self, *args, **kwargs):
        # Call the parent constructor
        super().__init__(*args, **kwargs)

        # start the audio mixer
        pygame.mixer.init()

        # load the audio for the game
        self.game_over_sound = pygame.mixer.Sound("./audio/game_over.wav")
        self.win_sound = pygame.mixer.Sound("./audio/win.wav")
        self.hit_sound = pygame.mixer.Sound("./audio/hit.wav")

        # Create objects

        # start ball

        self.ball = Ball()
        self.ball.launch()

        # make the players

        self.p1 = Paddle("left", color=constants.GREEN_COLOR)
        if self.game_mode == "ai":
            self.p2 = Paddle("right", color=constants.GAME_COLOR, speed=5)
        else:
            self.p2 = Paddle("right", color=constants.RED_COLOR)

        # reset scores
        self.p1_score = 0
        self.p2_score = 0

        # group them together
        self.paddles = pygame.sprite.Group()
        self.paddles.add(self.p1, self.p2)

        # will hold the time of win if player 1 wins a round
        self.player1_win = False
        # will hold the time of win if player 2 wins a round
        self.player2_win = False

        # different colored dots will have different point values, assigned randomly later as the game goes on
        self.point = 1
        if self.ball.color == constants.RED_COLOR:  # red = 1
            self.point = 1
        elif self.ball.color == constants.GAME_COLOR:  # base will be = 2
            self.point = 2
        elif self.ball.color == constants.GREEN_COLOR:  # green is
            self.point = 3

        # game over manager attribute
        self.game_over = False
        # will store data when the game has reloaded recently
        self.recent_reload = 0

    def process_event(self, event):
        """A loop used control the events of the game"""
        # we don't need anything checked so we can pass
        pass

    def reload(self):
        """This will be used to restart the game when the ball hits the wall"""
        # restart the ball
        self.recent_reload = int(self.fps / 2)
        self.ball.__init__(
            color=random.choice(
                [constants.GAME_COLOR, constants.RED_COLOR, constants.GREEN_COLOR]
            )
        )
        self.ball.launch()

        # restart the players

        self.p1.__init__("left", color=self.p1.color)
        self.p2.__init__("right", color=self.p2.color)
        if self.ball.color == constants.RED_COLOR:  # red = 1
            self.point = 1
        elif self.ball.color == constants.GAME_COLOR:  # base will be = 2
            self.point = 2
        elif self.ball.color == constants.GREEN_COLOR:  # green is
            self.point = 3

    def move_players(self):
        """controls how the players will move"""

        # set up the controls
        keys = pygame.key.get_pressed()
        # these controls will be used for player one
        if keys[pygame.locals.K_w]:
            self.p1.up()
        if keys[pygame.locals.K_s]:
            self.p1.down()

        # ai will take control of the player two
        if self.game_mode == "ai":
            if (self.ball.rect.y + self.ball.size / 2) < (
                self.p2.rect.y + self.p2.size[1] / 2
            ):
                self.p2.up()
            if (self.ball.rect.y + self.ball.size / 2) > (
                self.p2.rect.y + self.p2.size[1] / 2
            ):
                self.p2.down()

        # if ai is not on, set
        else:
            # these controls will be used for player two, if they are not an AI
            if keys[pygame.locals.K_UP]:
                self.p2.up()
            if keys[pygame.locals.K_DOWN]:
                self.p2.down()

    def hit_ball(self):
        """this will manage the collisions with the ball and paddels"""

        # general catch all collisions
        collision = pygame.sprite.spritecollide(self.ball, self.paddles, dokill=False)
        if collision:

            # check for the power shot (left)
            keys = pygame.key.get_pressed()
            if (
                self.ball.rect.x < constants.WINDOW_WIDTH / 2
                and keys[pygame.locals.K_LSHIFT]
            ):
                self.ball.bounce(power="left")
                # checks for right power shot

            elif (
                self.ball.rect.x > constants.WINDOW_WIDTH / 2
                and keys[pygame.locals.K_RSHIFT]
                and self.game_mode != "ai"
            ):
                self.ball.bounce(direction="right", power="right")
            # handel the defaults
            else:
                self.ball.bounce("left")

            pygame.mixer.Sound.play(self.hit_sound)

    def check_end(self):
        """This will check if the game has ended, or if the round is complete"""

        # ball hits right wall
        if self.ball.rect.x + self.ball.size == constants.WINDOW_WIDTH:

            # will activate if not in free mode
            if self.game_mode != "free":
                self.p1_score += self.point

                # player 1
                if self.p1_score < self.matches:
                    # store the frames for 3 seconds worth of time
                    self.player1_win = int(self.fps * 3)
            self.window.fill(self.p1.color)
            # play a little blip for the winner !! :)
            pygame.mixer.Sound.play(self.win_sound)
            # restart the game on a reload
            self.reload()

        # hit left wall
        if self.ball.rect.x == 0:

            # sets the not free mode settings
            if self.game_mode != "free":
                # player 2 score manager
                self.p2_score += self.point
                if self.p2_score < self.matches:
                    self.player2_win = int(self.fps * 3)
            pygame.mixer.Sound.play(self.win_sound)

            # restart the game
            self.reload()

        # check to see if the number of matches has been completed
        if self.p2_score >= self.matches or self.p1_score >= self.matches:
            # game over sound plays
            pygame.mixer.Sound.play(self.game_over_sound)
            # shut it down boys
            self.game_over = True
            self.running = False

    def process_loop(self):
        """This will be used for managing the main game"""

        # check if the round ends
        self.check_end()

        # print the scores at the top
        if self.game_mode != "free":
            self.print_out(
                constants.WINDOW_WIDTH / 2,
                constants.WINDOW_HEIGHT / 5,
                f"""Player One: { self.p1_score } {" "*40} Player Two: { self.p2_score }""",
                color=constants.GAME_COLOR,
                size=50,
            )

        # this will do a visual effect when the ball goes off the screen
        if self.recent_reload > 0:
            self.window.fill(
                tuple(
                    [
                        i - int(random.choice(range(self.recent_reload)) * 2)
                        if i - self.recent_reload * 2 <= 255
                        and i - self.recent_reload * 2 >= 0
                        else random.choice(range(255))
                        for i in list(constants.BACKGROUND_COLOR)
                    ]
                )
            )
            self.recent_reload -= 1

        # print the score update on the window

        # player 1 win print
        if self.player1_win > 0 and self.player1_win > self.player2_win:
            self.print_out(
                constants.WINDOW_WIDTH / 2,
                constants.WINDOW_HEIGHT / 2,
                f"Points to Player One! total: {self.p1_score}",
                color=self.p1.color,
            )
            self.player1_win -= 1

        # player 2 win print
        if self.player2_win > 0 and self.player2_win > self.player1_win:
            self.print_out(
                constants.WINDOW_WIDTH / 2,
                constants.WINDOW_HEIGHT / 2,
                f"Points to Player Two! total: {self.p2_score}",
                color=self.p2.color,
            )
            self.player2_win -= 1

        # this will move the players
        self.move_players()

        # this will check for collisions
        self.hit_ball()

        # Update the ball position
        self.ball.update()

        # Update the paddles' positions
        self.paddles.update()

        # Blit everything
        self.paddles.draw(self.window)

        # blit the the ball
        self.window.blit(self.ball.image, self.ball.rect)

        if self.ball.off_limits:
            return True

        return False
