import pygame
from constants import WINDOW_HEIGHT, WINDOW_WIDTH, GAME_COLOR, BACKGROUND_COLOR


class Screen:
    """
    Use the Screen class as a parent class for your own screens
    """

    def __init__(
        self,
        window,
        fps=60,
        bgcolor=None,
        game_mode="free",
        matches=10,
        p1_score=None,
        p2_score=None,
    ):
        """Constructor must receive the window"""
        self.window = window
        self.running = True
        self.fps = fps
        self.game_mode = game_mode
        self.bgcolor = bgcolor
        if not self.bgcolor:
            self.bgcolor = BACKGROUND_COLOR
        self.matches = matches

        self.p1_score = p1_score
        self.p2_score = p2_score

    def loop(self):
        """Main screen loop: deals with Pygame events"""

        self.clock = pygame.time.Clock()

        while self.running:
            self.clock.tick(self.fps)

            # Fill the screen
            self.window.fill(self.bgcolor)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False
                else:
                    # Override this method to customize your screens!
                    self.process_event(event)

            # Override this method to customize what happens in your screens!
            result = self.process_loop()

            # Update display
            pygame.display.update()

        return result

    def process_event(self, event):
        """This method should be overriden by your child classes"""

        print("YOU SHOULD IMPLEMENT 'process_event' IN YOUR SCREEN SUBCLASS!")

    def process_loop(self):
        """This method should be overriden by your child classes"""
        raise NotImplementedError("YOU MUST IMPLEMENT 'process_loop' IN YOUR SUBCLASS!")

    def print_out(
        self, x, y, content: str, color=GAME_COLOR, font="comic sans", size=20
    ):
        font_face = pygame.font.SysFont(
            font, int(((WINDOW_WIDTH * 3 + WINDOW_HEIGHT) / 4) / (size))
        )
        text = font_face.render(content, 1, color)

        self.window.blit(text, (x - text.get_width() / 2, y))
