import pygame
from .base_screen import Screen
from models.button import Button
from constants import WINDOW_HEIGHT, WINDOW_WIDTH, GAME_COLOR, GREEN_COLOR, RED_COLOR
import pygame.locals


class StartScreen(Screen):
    def __init__(self, *args, **kwargs):
        """Init the interface for the start menu for the game"""
        super().__init__(*args, **kwargs)  # brings in the Screen class content

        # add the objects to the screen
        # get the current screen size

        # make the free play mode button
        self.free_button = Button(
            WINDOW_WIDTH / 2 - WINDOW_WIDTH / 8,  # x
            WINDOW_HEIGHT / 3,  # y
            WINDOW_WIDTH / 4,  # width
            WINDOW_HEIGHT / 8,  # height
            "free",  # text
            GREEN_COLOR,
        )  # color

        # maked the rank play mode button
        self.ranked_button = Button(
            WINDOW_WIDTH / 2 - WINDOW_WIDTH / 8,  # x
            WINDOW_HEIGHT / 3 + WINDOW_HEIGHT / 7,  # y
            WINDOW_WIDTH / 4,  # width
            WINDOW_HEIGHT / 8,  # height
            "ranked",
        )  # text

        # starts the ai mode
        self.ai_button = Button(
            WINDOW_WIDTH / 2 - WINDOW_WIDTH / 8,  # x
            WINDOW_HEIGHT / 3 + WINDOW_HEIGHT / 7 * 2,  # y
            WINDOW_WIDTH / 4,  # width
            WINDOW_HEIGHT / 8,  # height
            "ai fight",  # text
            RED_COLOR,
        )

        # this will be set the the seleted button result
        self.result = False

        # import some audio for the buttons
        pygame.mixer.init()  # start mixer incase it is not on already
        self.hit_sound = pygame.mixer.Sound("./audio/hit.wav")

    def process_event(self, event):
        """The loop used to handel hovers, exits and selections for the start menu"""

        # these will make the button's hover color change
        if event.type == pygame.MOUSEMOTION:

            # free button
            self.free_button.hover((event.pos[0], event.pos[1]))

            # rank button
            self.ranked_button.hover((event.pos[0], event.pos[1]))

            # ai button
            self.ai_button.hover((event.pos[0], event.pos[1]))

        # this will exit the start and load the selected game mode
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x = event.pos[0]
            mouse_y = event.pos[1]

            if self.free_button.clicked((mouse_x, mouse_y)):

                self.result = "free"
                self.running = False
            if self.ranked_button.clicked((mouse_x, mouse_y)):

                self.result = "ranked"
                self.running = False
            if self.ai_button.clicked((mouse_x, mouse_y)):

                self.result = "ai"
                self.running = False

    def process_loop(self):

        # print the game name
        self.print_out(
            WINDOW_WIDTH / 2,
            WINDOW_HEIGHT / 10,
            "BOPPERS!",
            color=GAME_COLOR,
            size=20,
            font="comic sans",
        )

        # draw the buttons
        self.free_button.draw(self.window)
        self.ranked_button.draw(self.window)
        self.ai_button.draw(self.window)
